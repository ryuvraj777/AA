// geometry/rectangle.go

package geometry

// Function to calculate the area of a rectangle
func AreaOfRectangle(length, width float64) float64 {
	return length * width
}
